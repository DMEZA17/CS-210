/*
Daniel Meza
The purpose of this program is to get values from a user and then showing the user how their balance will look depending on what values they entered.
It then allows the user to make changes to their monthly deposits, annual interest and number of years until they see what works best for them.
*/

#include <iostream>
#include "AirgeadBanking.h"

using namespace std;

// Checks for input validation
void UserValues(double& initialInvestment, double& monthlyDeposit, double& annualInterest, int& numYears) {
    cout << "***************************************" << endl;
    cout << "************* Data Input **************" << endl;

    do {
        cout << "Enter an initial investment: $";
        cin >> initialInvestment;
        if (initialInvestment < 0) {
            cout << "Invalid number try again." << endl;
        }
    } while (initialInvestment < 0);

    do {
        cout << "Enter a monthly deposit: $";
        cin >> monthlyDeposit;
        if (monthlyDeposit < 0) {
            cout << "Invalid number try again." << endl;
        }
    } while (monthlyDeposit < 0);

    do {
        cout << "Enter annual interest: %";
        cin >> annualInterest;
        if (annualInterest < 0) {
            cout << "Invalid number try again." << endl;
        }
    } while (annualInterest < 0);

    do {
        cout << "Enter number of years: ";
        cin >> numYears;
        if (numYears < 0) {
            cout << "Invalid number try again." << endl;
        }
    } while (numYears < 0);

    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}


void DisplayMenu() {
    cout << "***************************************" << endl;
    cout << "*********** Menu Options **************" << endl;
    cout << "1. Change Monthly Deposit" << endl;
    cout << "2. Change Annual Interest" << endl;
    cout << "3. Change Number of Years" << endl;
    cout << "4. Recalculate" << endl;
    cout << "5. Exit" << endl;
    cout << "***************************************" << endl;
    cout << "Enter your choice: ";
}


int main() { // Main

    Banking airgead;
    int numYears = 0;
    double
        initialInvestment = 0.0,
        monthlyDeposit = 0.0,
        annualInterest = 0.0;

    UserValues(initialInvestment, monthlyDeposit, annualInterest, numYears);
    

    airgead.setInitialInvestment(initialInvestment);
    airgead.setMonthlyDeposit(monthlyDeposit);
    airgead.setAnnualInterest(annualInterest);
    airgead.setNumYears(numYears);

    airgead.calculateBalanceWithoutMonthlyDeposit(); 
    airgead.calculateBalanceWithMonthlyDeposit();

    bool exitProgram = false;
    while (!exitProgram) {
        DisplayMenu();
        int choice;
        cin >> choice;

        switch (choice) {
        case 1:
            // Change monthly deposit
            cout << "Enter new monthly deposit: $";
            cin >> monthlyDeposit;
            airgead.setMonthlyDeposit(monthlyDeposit);
            break;

        case 2:
            // Change annual interest
            cout << "Enter new annual interest: %";
            cin >> annualInterest;
            airgead.setAnnualInterest(annualInterest);
            break;

        case 3:
            // Change number of years
            cout << "Enter new number of years: ";
            cin >> numYears;
            airgead.setNumYears(numYears);
            break;

        case 4:
            // Recalculate balances
            cout << "Recalculating balance with and without monthly deposits..." << endl;
            airgead.calculateBalanceWithoutMonthlyDeposit();
            airgead.calculateBalanceWithMonthlyDeposit();
            break;
        case 5:
            // Exit
            exitProgram = true;
            cout << "Exiting program..." << endl;
            break;

        default:
            cout << "Invalid choice, try again." << endl;
        }
    }

    return 0;
}
