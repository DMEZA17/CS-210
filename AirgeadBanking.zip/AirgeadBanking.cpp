#include <iostream>
#include <iomanip>
#include "AirgeadBanking.h"

using std::cout;
using std::endl;
using std::fixed;
using std::setprecision;
using std::setw;
using std::right;

Banking::Banking() {
    InitialInvestment = 0.0;
    MonthlyDeposit = 0.0;
    AnnualInterest = 0.0;
    EarnedInterest = 0.0;
    NumYears = 0;
}

// Setter methods
void Banking::setInitialInvestment(double initialInvestment) {
    this->InitialInvestment = initialInvestment;
}

void Banking::setMonthlyDeposit(double monthlyDeposit) {
    this->MonthlyDeposit = monthlyDeposit;
}

void Banking::setAnnualInterest(double annualInterest) {
    this->AnnualInterest = annualInterest;
}

void Banking::setEarnedInterest(double earnedInterest) {
    this->EarnedInterest = earnedInterest;
}

void Banking::setNumYears(int numYears) {
    this->NumYears = numYears;
}

// Getter methods
double Banking::getInitialInvestment() const {
    return InitialInvestment;
}

double Banking::getMonthlyDeposit() const {
    return MonthlyDeposit;
}

double Banking::getAnnualInterest() const {
    return AnnualInterest;
}

int Banking::getNumYears() const {
    return NumYears;
}

double Banking::getEarnedInterest() const {
    return EarnedInterest;
}

// Calculate balance without monthly deposit and also lines up output.
double Banking::calculateBalanceWithoutMonthlyDeposit() {
    double balance = InitialInvestment;

    cout << "==========================================================================" << endl;
    cout << "Balance and Interest Without Additional Monthly Deposits" << endl;
    cout << "==========================================================================" << endl;
    cout << "Year              Year End Balance            Year End Earned Interest" << endl;
    cout << "==========================================================================" << endl;

    for (int year = 1; year <= NumYears; ++year) {
        EarnedInterest = balance * (AnnualInterest / 100);
        balance += EarnedInterest;

        if (balance < 1000) {
            cout << setw(2) << year << setw(17) << fixed << setprecision(2) << right << "$" << balance
                << setw(24) << fixed << setprecision(2) << "$" << EarnedInterest << endl;

        }

        else if (balance > 10000) {
            cout << setw(2) << year << setw(17) << fixed << setprecision(2) << right << "$" << balance
                << setw(20) << fixed << setprecision(2) << "$" << EarnedInterest << endl;
        }
        else {
            cout << setw(2) << year << setw(17) << fixed << setprecision(2) << right << "$" << balance
                << setw(21) << fixed << setprecision(2) << "$" << EarnedInterest << endl;
        }
    }

    return balance;
}

// Calculates balance with monthly deposits and also lines up output.
double Banking::calculateBalanceWithMonthlyDeposit() {
    double balance = InitialInvestment;

    cout << "==========================================================================" << endl;
    cout << "Balance and Interest With Additional Monthly Deposits" << endl;
    cout << "==========================================================================" << endl;
    cout << "Year              Year End Balance            Year End Earned Interest" << endl;
    cout << "==========================================================================" << endl;

    for (int year = 1; year <= NumYears; ++year) {
        EarnedInterest = 0;
        
        for (int month = 1; month <= 12; ++month) {
            double monthlyInterest = (balance + MonthlyDeposit) * (AnnualInterest / 100 / 12);
            balance += MonthlyDeposit + monthlyInterest;
            EarnedInterest += monthlyInterest;

        }

        if (balance < 1000) {
            cout << setw(2) << year << setw(17) << fixed << setprecision(2) << right << "$" << balance
                << setw(22) << fixed << setprecision(2) << "$" << EarnedInterest << endl;

        } 

        else if (balance >10000){
            cout << setw(2) << year << setw(17) << fixed << setprecision(2) << right << "$" << balance
                << setw(20) << fixed << setprecision(2) << "$" << EarnedInterest << endl;
        }
        else {
            cout << setw(2) << year << setw(17) << fixed << setprecision(2) << right << "$" << balance
                << setw(21) << fixed << setprecision(2) << "$" << EarnedInterest << endl;
        }
    }

    return balance;
}