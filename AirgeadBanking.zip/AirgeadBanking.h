#pragma once
#ifndef banking_h
#define banking_h

#include <string>

class Banking {

private:
	double
		InitialInvestment,
		MonthlyDeposit,
		AnnualInterest,
		EarnedInterest;
	int NumYears;

public:
	Banking();
	// setters
	void setInitialInvestment(double initialInvestment);
	void setMonthlyDeposit(double monthlyDeposit);
	void setAnnualInterest(double annualInterest);
	void setEarnedInterest(double earnedInterest);
	void setNumYears(int numYears);
	// getters
	double getInitialInvestment() const;
	double getMonthlyDeposit() const;
	double getAnnualInterest() const;
	double getEarnedInterest() const;
	int	getNumYears() const;


	double calculateBalanceWithoutMonthlyDeposit();
	double calculateBalanceWithMonthlyDeposit();
};

#endif